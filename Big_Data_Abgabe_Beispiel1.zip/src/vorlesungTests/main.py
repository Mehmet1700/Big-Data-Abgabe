


def main():
    from src.vorlesungTests.vorlesungMain.sparkSample import runSpark
    runSpark()



if __name__== '__main__':
    '''
    This is the main entry point of our App Everything starts here
    PLEASE KEEP THIS ROUTINE FLAT
    '''
    main()